/*
 * album.h
 *
 *  Created on: 1 may. 2022
 *      Author: Nicolas Praconovo
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "input.h"
#include "menu.h"

#include "artista.h"
#include "tipoArtista.h"
#include "genero.h"
#include "tipoAlbum.h"

#define TITULO_LENGHT 51

#define TRUE 1
#define FALSE 0

#ifndef ALBUM_H_
#define ALBUM_H_

typedef struct
{
	int dia;
	int mes;
	int anio;

} Fecha;

typedef struct
{
	int id;
	char titulo[TITULO_LENGHT];
	Fecha fechaPublicacion;
	float precio;

	int idArtista;
	int idGenero;
	int idTipoAlbum;

	int isEmpty;

} Album;

/**
 * \brief Inicializa el array en el campo isEmpty en TRUE.
 *
 * \param list Puntero. Lista de elementos de Album.
 * \param len Cantidad de elementos de Album.
 *
 * \return Retorna -1 si hubo un error, en caso contario 0.
 */
int album_inicializar(Album* list, int len);

/**
 * \brief Hardcodeo de datos para la estructura Album.
 *
 * \param list Puntero. Lista de elementos de Album.
 * \param len Cantidad de elementos de Album.
 * \param id Puntero. Referencia al valor del ID de la estructura.
 *
 * \return Retorna -1 si hubo un error, en caso contario 0.
 */
int album_hardcodeo(Album* list, int len, int* id);

/**
 * \brief Busca el ID en la lista que concuerde.
 *
 * \param list Puntero. Lista de elementos de Album.
 * \param len Cantidad de elementos de Album.
 * \param id Id a ser buscado.
 *
 * \return Retorna el indice en donde esta el id en cuestion.
 */
int album_buscarPorId(Album* list, int len, int id);

/**
 * \brief Busca un indice libre.
 *
 * \param list Puntero. Lista de elementos de Album.
 * \param len Cantidad de elementos de Album.
 * \param index
 *
 * \return Retorna -1 si hubo un error, en caso contario 0.
 */
int buscarLibre(Album* list, int len, int* index);

/**
 * \brief Revisa si el array esta vacio
 *
 * \param list Puntero. Lista de elementos de Album.
 * \param len Cantidad de elementos de Album.
 *
 * \return Retorna -1 si hubo un error, en caso contario 0.
 */
int arrayIsEmpty(Album* list, int len);

/**
 * \brief Busca si la fecha concuerda con la ingresada.
 *
 * \param list Puntero. Lista de elementos de Album.
 * \param len Cantidad de elementos de Album.
 * \param id la fecha a verificar.
 *
 * \return Devuelve la ubiacion de la fecha en cuestion.
 */
int fecha_buscarFecha(Album* list, int len, int id);

// CARGA

/**
 * \brief Carga un elemento al array.
 *
 * \param list Puntero. Lista de elementos de Album.
 * \param len Cantidad de elementos de Album.
 * \param id Puntero. Valor que se le dara al ID de la estructura
 *
 * \return Retorna -1 si hubo un error, en caso contario 0.
 */
int album_cargarUno(Album* list, int len, int* id);

/**
 * \brief Carga los datos al array.
 *
 * \param list Puntero. Lista de elementos de Album.
 * \param len Cantidad de elementos de Album.
 * \param id El valor que tendra la id en la estructura
 * \param titulo Nombre del Album
 * \param dia Dia de cuando salio el Album.
 * \param mes Mes de cuando salio el Album.
 * \param anio A�o de cuando salio el Album.
 * \param idArtista ID que identifica al Artista creador del album.
 * \param idGenero ID que identifica el genero del Album.
 * \param idTipoAlbum ID que identifica el tipo del album.
 *
 * \return Retorna -1 si hubo un error, en caso contario 0.
 */
int album_cargarEnArray(Album* list, int len, int id, char titulo[], int dia, int mes, int anio, int idArtista, int idGenero, int idTipoAlbum);

/**
 * \brief Pide los datos de la fecha de publicacion de un Albm.
 *
 * \param dia Dia de cuando salio el Album.
 * \param mes Mes de cuando salio el Album.
 * \param anio A�o de cuando salio el Album.
 *
 * \return Retorna -1 si hubo un error, en caso contario 0.
 */
int album_cargarFecha(int* dia, int* mes, int* anio);

// BAJA

/**
 * \brief Realiza la baja de un Album.
 *
 * \param list Puntero. Lista de Albumes.
 * \param artista Puntero. Lista de Artistas.
 * \param tipo Puntero. Lista de Tipos de Artistas.
 * \param genero Puntero. Lista de Generos.
 * \param tipoAlbum. Puntero. Lista de Tipos de Albumes.
 * \param len Cantidad de elementos de Album.
 * \param id ID del album el cual sera eliminado
 *
 * \return Retorna -1 si hubo un error, 0 si el album fue eliminado o 1 si el usuario cancelo el borrar.
 */
int album_baja(Album* list, Artista* artista, TipoArtista* tipo, Genero* genero, TipoAlbum* tipoAlbum, int len, int id);

// MODIFICACION

/**
 * \brief Verifica que el usuario este seguro de modificar el usuario.
 *
 * \param list Puntero. Lista de Albumes.
 * \param artista Puntero. Lista de Artistas.
 * \param tipo Puntero. Lista de Tipos de Artistas.
 * \param genero Puntero. Lista de Generos.
 * \param tipoAlbum. Puntero. Lista de Tipos de Albumes.
 * \param len Cantidad de elementos de Album.
 * \param id ID del album el cual sera modificado
 *
Retorna -1 si hubo un error, 0 si el album fue eliminado o 1 si el usuario cancelo el borrar.
 */
int album_modificar(Album* list, Artista* artista, TipoArtista* tipo, Genero* genero, TipoAlbum* tipoAlbum, int len, int id);

/**
 * \brief Realiza la modificacion de un Album.
 *
 * \param list Puntero. Lista de Albumes.
 * \param len Cantidad de elementos de Album.
 * \param index Indice en donde se encuentra el Album a modificar.
 * \return
 */
int album_modificarAlbum(Album* list, int len, int index);

// INFORMAR

int album_calcularInforme(Album* list, int len);

int album_contador(Album* list, int len, int* contador);

int album_acumulador(Album* list, int len, float* acumulador);

int album_calcularPromedio(Album* list, int len, int* contador, float* promedio, float* acumulador);

int album_excedePromedio(Album* list, int len, int* contador, float* acumulador, float* promedio, int* contadorExcede);

int album_mostrarResultados(float acumulador, float promedio, int contadorExcede, int contadorAntes2000);

int album_contarAlbumsAntes2000(Album* list, int len, int* contador);

// ORDENAR

int album_ordenDeOrdenamiento(Album* list, int len, int* order);

int album_ordenamientoPorImporte(Album* list, int len, int order);

int album_ordenamientoPorTitulo(Album* list, int len, int order);

// MOSTRAR

int album_menuMostrar(Album* list, Artista* artista, TipoArtista* tipo, Genero* genero, TipoAlbum* tipoAlbum, int len, int lenArtista, int lenTipo, int lenGenero, int lenTipoAlbum);

int album_mostrarUno(Album* unAlbum, Artista* unArtista, TipoArtista* tipo, Genero* genero, TipoAlbum* tipoAlbum);

int album_mostrarAlbums(Album* list, int len, Artista* listArtista, int lenArtista,TipoArtista* listTipo, int lenTipo, Genero* listGenero, int lenGenero, TipoAlbum* listTipoAlbum, int lenTipoAlbum);

// INFORMES 2

int album_mostrarAlbumsAntes2000(Album* list, Artista* artista, TipoArtista* tipo, Genero* genero, TipoAlbum* tipoAlbum, int len);

int album_mostrarAlbumsExcedePromedio(Album* list, Artista* artista, TipoArtista* tipo, Genero* genero, TipoAlbum* tipoAlbum, int len);

int album_mostrarTodosLosAlbumsPorArtista(Album* list, Artista* artista, TipoArtista* tipo, Genero* genero, TipoAlbum* tipoAlbum, int len, int lenArtista);

int album_mostrarAlbumsPorAnio(Album* list, Artista* artista, TipoArtista* tipo, Genero* genero, TipoAlbum* tipoAlbum, int len);

int album_albumMasCaro(Album* list, Artista* artista, TipoArtista* tipo, Genero* genero, TipoAlbum* tipoAlbum, int len);

// INFORMES 3 - 2da Parte

int album_albumesNoVinilo(Album* list, Artista* artista, TipoArtista* tipo, Genero* genero, TipoAlbum* tipoAlbum1, int len);

int album_mostrarAlbumesDeViniloPorArtista(Album* list, Artista* artista, TipoArtista* tipo, Genero* genero, TipoAlbum* tipoAlbum1, int len, int lenArtista, int lenTipo, int lenGenero, int lenTipoAlbum);

#endif /* ALBUM_H_ */
