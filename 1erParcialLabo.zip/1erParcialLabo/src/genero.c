/*
 * genero.c
 *
 *  Created on: 1 may. 2022
 *      Author: Nicolas Praconovo
 */

#include "genero.h"

int genero_hardcode(Genero* list, int len, int* id)
{
	int toReturn = -1;

	int i;
	int cant;

	Genero auxGenero[] =
	{
			{0, "Rock", 			FALSE},
			{0, "Pop", 				FALSE},
			{0, "Electronica", 		FALSE},
			{0, "Jazz", 			FALSE},
			{0, "Bandas Sonoras", 	FALSE},
			{0, "K-Pop", 			FALSE},
			{0, "Country", 			FALSE},
			{0, "Clasica", 			FALSE},
			{0, "Reggaeton", 		FALSE},
			{0, "J-Pop", 			FALSE}
	};

	if(list != NULL && len > 0)
	{
		cant = sizeof(auxGenero) / sizeof(Genero);

		if(cant <= len)
		{
			for(i = 0; i < cant; i++)
			{
				list[i] = auxGenero[i];
				list[i].id = *id;

				(*id)++;
			}

			toReturn = 0;
		}
	}

	return toReturn;
}

int genero_buscarPorId(Genero* list, int len, int id)
{
	int toReturn = -1;

	int i;

	if(list != NULL && len > 0)
	{
		for(i = 0; i < len; i++)
		{
			if(list[i].id == id)
			{
				toReturn = i;
				break;
			}
		}
	}

	return toReturn;
}

int genero_mostrarUno(Genero* unGenero)
{
	int toReturn = -1;

	if(unGenero != NULL)
	{
		//ID 	GENERO
		printf("%d %15s\n", unGenero->id, unGenero->descripcion);

		toReturn = 0;
	}

	return toReturn;
}

int genero_mostrarGeneros(Genero* list, int len)
{
	int toReturn = -1;

	int i;

	int flag = FALSE;

	if(list != NULL && len > 0)
	{
		printf("\n\n");
		fflush(stdin);
		system("pause");

		printf("\tLISTA DE GENEROS\n\n");
		printf("ID \t GENEROS\n\n");

		for(i = 0; i < len; i++)
		{
			if(list[i].isEmpty == FALSE && genero_mostrarUno(&list[i]))
			{
				flag = TRUE;
			}
		}

		if(flag)
		{
			toReturn = 0;
		}
	}

	return toReturn;
}


