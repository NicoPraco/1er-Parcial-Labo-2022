/*
 * genero.h
 *
 *  Created on: 1 may. 2022
 *      Author: Nicolas Praconovo
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "input.h"
#include "menu.h"

#define GENERO_LENGHT 51

#define TRUE 1
#define FALSE 0

#ifndef GENERO_H_
#define GENERO_H_

typedef struct
{
	int id;
	char descripcion[GENERO_LENGHT];

	int isEmpty;

} Genero;

/**
 * \brief Hardcodea los datos de Genero.
 *
 * \param list Lista de Genero.
 * \param len Cantidad de Elementos.
 * \param id ID el cual tendra los datos de la estructura.
 *
 * \return Retorna -1 si hubo un error, en caso contrario 0.
 */
int genero_hardcode(Genero* list, int len, int* id);

/**
 * \brief Busca si el ID existe
 *
 * \param list Lista de Genero.
 * \param len Cantidad de Elementos
 * \param id ID a verificar.
 *
 * \return Retorna -1 si hubo un error, en caso contrario 0.
 */
int genero_buscarPorId(Genero* list, int len, int id);

/**
 * \brief Muestra un solo genero.
 *
 * \param unGenero
 *
 * \return Retorna -1 si hubo un error, en caso contrario 0.
 */
int genero_mostrarUno(Genero* unGenero);

/**
 * \brief Muestra la lista de generos.
 *
 * \param list Lista de Genero.
 * \param len Cantidad de Elementos
 *
 * \return Retorna -1 si hubo un error, en caso contrario 0.
 */
int genero_mostrarGeneros(Genero* list, int len);

#endif /* GENERO_H_ */
