/*
 * artista.h
 *
 *  Created on: 1 may. 2022
 *      Author: Nicolas Praconovo
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "input.h"
#include "menu.h"

#include "tipoArtista.h"

#define NOMBRE_LENGHT 51

#define TRUE 1
#define FALSE 0

#ifndef ARTISTA_H_
#define ARTISTA_H_

typedef struct
{
	int id;
	char nombre[NOMBRE_LENGHT];
	int idTipoArtista;

	int isEmpty;

} Artista;

/**
 * \brief Hardcodea los datos de Artista.
 *
 * \param list Lista de Artista.
 * \param len Cantidad de Elementos.
 * \param id ID el cual tendra los datos de la estructura.
 *
 * \return Retorna -1 si hubo un error, en caso contrario 0.
 */
int artista_hardcodeo(Artista* list, int len, int* id);

/**
 * \brief Busca si el ID existe
 *
 * \param list Lista de Artistas.
 * \param len Cantidad de Elementos
 * \param id ID a verificar.
 *
 * \return Retorna -1 si hubo un error, en caso contrario 0.
 */
int artista_buscarPorId(Artista* list, int len, int id);

/**
 * \brief Muestra un solo tipo de Artista.
 *
 * \param unArrista
 *
 * \return Retorna -1 si hubo un error, en caso contrario 0.
 */
int artista_mostrarUno(Artista* unArtista, TipoArtista* tipo);

/**
 * \brief Muestra la lista de Artistas.
 *
 * \param list Lista de Genero.
 * \param len Cantidad de Elementos
 *
 * \return Retorna -1 si hubo un error, en caso contrario 0.
 */
int artista_mostrarArtistas(Artista* list, TipoArtista* listTipo, int len, int lenTipo);

#endif /* ARTISTA_H_ */
