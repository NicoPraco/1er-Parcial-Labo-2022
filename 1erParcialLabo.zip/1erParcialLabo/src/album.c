/*
 * album.c
 *
 *  Created on: 1 may. 2022
 *      Author: Nicolas Praconovo
 */

#include "album.h"

int album_inicializar(Album* list, int len)
{
	int toReturn = -1;

	int i;

	if(list != NULL && len > 0)
	{
		for(i = 0; i < len; i++)
		{
			list[i].isEmpty = TRUE;
		}

		toReturn = 0;
	}

	return toReturn;
}

/*
 * 	ARTISTAS
 *
 	{0, "The Beatles", 2},
	{0, "Michael Jackson", 1},
	{0, "Ed Sheeran", 1},
	{0, "Hans Zimmer", 1},
	{0, "Aimer", 1},
	{0, "U2", 2}

	GENERO

	{0, "Rock"},
	{0, "Pop"},
	{0, "Electronica"},
	{0, "Jazz"},
	{0, "Bandas Sonoras"},
	{0, "K-Pop"},
	{0, "Country"},
	{0, "Clasica"},
	{0, "Reggaeton"},
	{0, "J-Pop"}
 */

int album_hardcodeo(Album* list, int len, int* id)
{
	int toReturn = -1;

	int i;
	int cant;
	int index;

	int flag = FALSE;

	Album auxAlbum[] =
	{
			// ID - ALBUM - FECHA - PRECIO IDs 1� Artista - 2� Genero - isEmpty
			{0, "Thriller", 						{30, 11, 1982}, 500, 2, 2, 1, FALSE},
			{0, "=", 								{03, 03, 2017}, 500, 2, 2, 3, FALSE},
			{0, "Dune", 							{17, 9, 2021}, 	500, 4, 5, 3, FALSE},
			{0, "Now That's What I Call Music!", 	{16, 02, 2004}, 500, 6, 1, 1, FALSE},
			{0, "Help", 							{06, 06, 1965}, 500, 1, 1, 2, FALSE}

	};

	if(list != NULL && len > 0 && id != NULL)
	{
		cant = sizeof(auxAlbum) / sizeof(Album);

		if(cant <= len)
		{
			for(i = 0; i < cant; i++)
			{
				if(!buscarLibre(list, len, &index))
				{
					list[index] = auxAlbum[i];
					list[i].id = *id;

					(*id)++;

					flag = TRUE;
				}
			}

			if(flag)
			{
				toReturn = 0;
			}
		}
	}

	return toReturn;
}

int album_buscarPorId(Album* list, int len, int id)
{
	int toReturn = -1;

	int i;

	if(list != NULL && len > 0 && id > 0 && id < len)
	{
		for(i = 0; i < len; i++)
		{
			if(list[i].isEmpty == FALSE && list[i].id == id)
			{
				toReturn = i;
				break;
			}
		}
	}

	return toReturn;
}

int buscarLibre(Album* list, int len, int* index)
{
	int toReturn = -1;

	int i;

	if(list != NULL && len > 0 && index != NULL)
	{
		for(i = 0; i < len; i++)
		{
			if(list[i].isEmpty == TRUE)
			{
				*index = i;
				toReturn = 0;
				break;
			}
		}
	}

	return toReturn;
}

int arrayIsEmpty(Album* list, int len)
{
	int toReturn = -1;

	int i;

	if(list != NULL && len > 0)
	{
		for(i = 0; i < len; i++)
		{
			if(list[i].isEmpty == FALSE)
			{
				toReturn = 0;
				break;
			}
		}
	}

	return toReturn;
}

int fecha_buscarFecha(Album* list, int len, int id)
{
	int toReturn = -1;

	int i;

	if(list != NULL && len > 0 && id > 0 && id < len)
	{
		for(i = 0; i < len; i++)
		{
			if(list[i].fechaPublicacion.anio == id)
			{
				toReturn = id;
				break;
			}
		}
	}

	return toReturn;
}

// ============================ CARGA ============================

int album_cargarUno(Album* list, int len, int* id)
{
	int toReturn = -1;

	char titulo[TITULO_LENGHT];
	int dia;
	int mes;
	int anio;

	int idArtista;
	int idGenero;
	int idTipoAlbum;

	if(list != NULL && len > 0 && id != NULL)
	{
		if(!getString(titulo, "\nIngrese el nombre del album: ", "Error, vuelva a intenarlo: ", 1, 50) &&
		   !album_cargarFecha(&dia, &mes, &anio) &&
		   !album_menuArtistas(&idArtista) &&
		   !album_menuGenero(&idGenero) &&
		   !album_menuTipoAlbum(&idTipoAlbum) &&
		   !album_cargarEnArray(list, len, *id, titulo, dia, mes, anio, idArtista, idGenero, idTipoAlbum))
		{
			(*id)++;

			toReturn = 0;
		}
	}

	return toReturn;
}

int album_cargarEnArray(Album* list, int len, int id, char titulo[], int dia, int mes, int anio, int idArtista, int idGenero, int idTipoAlbum)
{
	int toReturn = -1;

	int index;

	if(list != NULL && len > 0)
	{
		if(!buscarLibre(list, len, &index))
		{
			list[index].id = id;

			strncpy(list[index].titulo, titulo, TITULO_LENGHT);
			list[index].fechaPublicacion.dia = dia;
			list[index].fechaPublicacion.mes = mes;
			list[index].fechaPublicacion.anio = anio;

			list[index].idArtista = idArtista;
			list[index].idGenero = idGenero;
			list[index].idTipoAlbum = idTipoAlbum;

			list[index].isEmpty = FALSE;

			toReturn = 0;
		}
	}

	return toReturn;
}

int album_cargarFecha(int* dia, int* mes, int* anio)
{
	int toReturn = -1;

	int flag = FALSE;

	if(dia != NULL && mes != NULL && anio != NULL)
	{
		if(!getInt(mes, "\nIngrese el mes del lanzamiento del album: ", "Error, vuelva a intenarlo: ", 1, 12))
		{
			switch(*mes)
			{
				case 1:
				case 3:
				case 5:
				case 7:
				case 8:
				case 10:
				case 12:
					if(!getInt(dia, "\nIngrese el dia del lanzamiento del album: ", "Error, solo numeros entre 1 y 31: ", 1, 31))
					{
						flag = TRUE;
					}
					break;

				case 4:
				case 6:
				case 9:
				case 11:
					if(!getInt(dia, "\nIngrese el dia del lanzamiento del album: ", "Error, solo numeros entre 1 y 30: ", 1, 30))
					{
						flag = TRUE;
					}
					break;

				case 2:
					if(!getInt(dia, "\nIngrese el dia del lanzamiento del album: ", "Error, solo numeros entre 1 y 28: ", 1, 28))
					{
						flag = TRUE;
					}
					break;

				default:
					printf("\n\aError, ha ingresado un valor invalido.\n");
					break;
			}

			if(!getInt(anio, "\nIngrese el anio del lanzamiento del album: ", "Error, solo numeros entre 1950 y 2021: ", 1950, 2021))
			{
				if(flag)
				{
					toReturn = 0;
				}
			}
		}
	}

	return toReturn;
}

// ============================ BAJA ============================

int album_baja(Album* list, Artista* artista, TipoArtista* tipo, Genero* genero, TipoAlbum* tipoAlbum, int len, int id)
{
	int toReturn = -1;

	int index;
	int respuesta;

	if(list != NULL && len > 0)
	{
		index = album_buscarPorId(list, len, id);

		if(index > -1)
		{
			printf("\n\n");
			fflush(stdin);
			system("pause");
			system("cls");

			printf("BAJA DE ALBUM\n\n");
			printf("ID \tTITULO \t\tFECHA DE PUBLICACION \tPRECIO \t\tARTISTA \tTIPO DE ARTISTA \tGENERO\n\n");
			album_mostrarUno(list, artista, tipo, genero, tipoAlbum);

			printf("\n0. = NO\n");
			printf("1. SI\n");

			if(getInt(&respuesta, "\nEsta seguro de eliminar el album: ", "Error, solo 0 o 1: ", 0, 1))
			{
				switch(respuesta)
				{
				case 0:
					toReturn = 1;
					break;

				case 1:
					list[index].isEmpty = TRUE;

					toReturn = 0;
					break;

				default:
					printf("\n\aError, ha ingresado un valor invalido\n");
					break;
				}
			}
		}
	}

	return toReturn;
}

// ============================ MODIFICAR ============================

int album_modificar(Album* list, Artista* artista, TipoArtista* tipo, Genero* genero, TipoAlbum* tipoAlbum, int len, int id)
{
	int toReturn = -1;

	int index;
	int respuesta;

	if(list != NULL && artista != NULL && tipo != NULL && genero != NULL && len > 0)
	{
		index = album_buscarPorId(list, len, id);

		if(index > -1)
		{
			printf("\n\n");
			fflush(stdin);
			system("pause");
			system("cls");

			printf("BAJA DE ALBUM\n\n");
			printf("ID \tTITULO \t\tFECHA DE PUBLICACION \tPRECIO \t\tARTISTA \tTIPO DE ARTISTA \tGENERO\n\n");
			album_mostrarUno(list, artista, tipo, genero, tipoAlbum);

			printf("\n0. = NO\n");
			printf("1. SI\n");

			if(getInt(&respuesta, "\nEsta seguro de modificar el album: ", "Error, solo 0 o 1: ", 0, 1))
			{
				switch(respuesta)
				{
				case 0:
					toReturn = 1;
					break;

				case 1:
					if(!album_modificarAlbum(list, len, index))
					{
						toReturn = 0;
					}
					break;

				default:
					printf("\n\aError, ha ingresado un valor invalido\n");
					break;
				}
			}
		}
	}

	return toReturn;
}

int album_modificarAlbum(Album* list, int len, int index)
{
	int toReturn = -1;

	int option;

	int flag = TRUE;

	Album auxAlbum;

	if(list != NULL && len > 0 && index > -1)
	{
		do
		{
			if(!album_ModificarMenu(&option))
			{
				switch(option)
				{
					case 1:
						if(!getString(auxAlbum.titulo, "\nIngrese el nuevo titulo del album: ", "Error, vuelva a intentarlo: ", 1, TITULO_LENGHT))
						{
							strncpy(list[index].titulo, auxAlbum.titulo, TITULO_LENGHT);

							flag = TRUE;
						}
						break;

					case 2:
						if(!album_cargarFecha(&auxAlbum.fechaPublicacion.dia, &auxAlbum.fechaPublicacion.mes, &auxAlbum.fechaPublicacion.anio))
						{
							list[index].fechaPublicacion.dia = auxAlbum.fechaPublicacion.dia;
							list[index].fechaPublicacion.mes = auxAlbum.fechaPublicacion.mes;
							list[index].fechaPublicacion.anio = auxAlbum.fechaPublicacion.anio;

							flag = TRUE;
						}
						break;

					case 3:
						if(!getFloat(&auxAlbum.precio, "\nIngrese el nuevo precio del album: ", "Error, vuelva a intentarlo:", 100, 100000))
						{
							list[index].precio = auxAlbum.precio;

							flag = TRUE;
						}
						break;

					case 4:
						printf("\nSaliendo...\n\n");
						break;

					default:
						printf("\n\aError, ha ingresado un valor invalido.");
						break;
				}

				printf("\n\n");
				fflush(stdin);
				system("pause");
				system("cls");
			}

		}while(option != 4);

		if(flag)
		{
			toReturn = 0;
		}
	}

	return toReturn;
}

// ============================ ORDENAR ============================

int album_ordenDeOrdenamiento(Album* list, int len, int* order)
{
	int toReturn = -1;

	int option;

	int flag = FALSE;

	if(list != NULL && len > 0 && order != NULL)
	{
		do
		{
			if(!album_menuOrdenamiento(&option))
			{
				switch (option)
				{
					case 1:
						*order = 1;

						flag = TRUE;
						break;

					case 2:
						*order = 0;

						flag = TRUE;
						break;

					default:
						printf("\n\aError, ha ingresado un valor invalido.\n");
						break;
				}
			}
		}while(option != 1 && option != 2);

		if(flag)
		{
			toReturn = 0;
		}
	}

	return toReturn;
}

int album_ordenamientoPorImporte(Album* list, int len, int order)
{
	int toReturn = -1;

	int i;
	int auxLen;
	int flagSwap;

	Album auxAlbum;

	if(list != NULL && len > 0 && (order == 1 || order == 0))
	{
		auxLen = len;

		do
		{
			flagSwap = FALSE;

			for(i = 0; i < auxLen - 1; i++)
			{
				if(list[i].isEmpty == FALSE && list[i + 1].isEmpty == FALSE)
				{
					if( (list[i].precio > list[i + 1].precio && order == 1) || (list[i].precio < list[i + 1].precio && order == 0) )
					{
						auxAlbum = list[i];
						list[i] = list[i + 1];
						list[i + 1] = auxAlbum;

						flagSwap = TRUE;
					}
				}
			}
			auxLen--;

		}while(flagSwap);

		return toReturn;
	}

	return toReturn;
}

int album_ordenamientoPorTitulo(Album* list, int len, int order)
{
	int toReturn = -1;

	int i;
	int auxLen;
	int flagSwap;
	int auxCmp;

	Album auxAlbum;

	if(list != NULL && len > 0 && (order == 1 || order == 0))
	{
		auxLen = len;

		do
		{
			flagSwap = FALSE;

			for(i = 0; i < auxLen - 1; i++)
			{
				if(list[i].isEmpty == FALSE && list[i + 1].isEmpty == FALSE)
				{
					auxCmp = strncmp(list[i].titulo, list[i + 1].titulo, TITULO_LENGHT);

					if( ((auxCmp > 0 || auxCmp == 0) && order == 1) || ((auxCmp < 0 || auxCmp == 0) && order == 0 ))
					{
						auxAlbum = list[i];
						list[i] = list[i + 1];
						list[i + 1] = auxAlbum;

						flagSwap = TRUE;
					}
				}
			}
			auxLen--;

		}while(flagSwap);

		toReturn = 0;
	}

	return toReturn;
}

// ============================ MOSTRAR ============================

int album_menuMostrar(Album* list, Artista* artista, TipoArtista* tipo, Genero* genero, TipoAlbum* tipoAlbum, int len, int lenArtista, int lenTipo, int lenGenero, int lenTipoAlbum)
{
	int toReturn = 0;

	int option;
	int optionSubMenu;
	int order;

	int flag = FALSE;

	if(list != NULL && artista != NULL && tipo != NULL && genero != NULL && tipoAlbum != NULL && len > 0 && lenArtista >0  && lenTipo > 0 && lenGenero > 0 && lenTipoAlbum > 0)
	{
		do
		{
			printf("\n\n");
			fflush(stdin);
			system("pause");
			system("cls");

			if(!album_subMenuListar(&option))
			{
				switch (option)
				{
					case 1:
						// TODOS LOS GENEROS
						if(!genero_mostrarGeneros(genero, lenGenero))
						{
							printf("\nLista de Generos mostrada con exito.\n");

							flag = TRUE;
						}
						else
						{
							printf("\n\aError al mostrar la lista de generos.\n");
						}
						break;

					case 2:
						//TODOS LOS TIPOS DE ARTISTAS
						if(!tipoArtista_mostrarTipos(tipo, lenTipo))
						{
							printf("\nLista de Tipos mostrada con exito.\n");

							flag = TRUE;
						}
						else
						{
							printf("\n\aError al mostrar la lista de tipos.\n");
						}
						break;

					case 3:
						// TODOS LOS ARTISTAS
						if(!artista_mostrarArtistas(artista, tipo, lenArtista, lenTipo))
						{
							printf("\nLista de Artistas mostrada con exito.\n");

							flag = TRUE;
						}
						else
						{
							printf("\n\aError al mostrar la lista de artistas.\n");
						}
						break;

					case 4:
						// TODOS LOS ALBUMS
						if(!album_mostrarAlbums(list, len, artista, lenArtista, tipo, lenTipo, genero, lenGenero, tipoAlbum, lenTipoAlbum))
						{
							printf("\nLista de Albumes mostrada con exito.\n");

							flag = TRUE;
						}
						else
						{
							printf("\n\aError al mostrar la lista de albumes.\n");
						}
						break;

					case 5:
						/* LISTA ORDENADA
						 * 1. POR IMPORTE
						 * 2. POR TITULO
						 */
						if(!album_subMenuOrdenamiento(&optionSubMenu) )
						{
							do
							{
								switch (optionSubMenu)
								{
									case 1:
										if(!album_ordenDeOrdenamiento(list, len, &order) && !album_ordenamientoPorImporte(list, len, order))
										{
											printf("\nMostrar lista ordenada por importe realizado con exito.\n");

											flag = TRUE;
										}
										else
										{
											printf("\n\aError al mostrar la lista ordenada por importe.\n");
										}
										break;

									case 2:
										if(!album_ordenDeOrdenamiento(list, len, &order) && !album_ordenamientoPorTitulo(list, len, order))
										{
											printf("\nMostrar lista ordenada por titulo realizado con exito.\n");

											flag = TRUE;
										}
										else
										{
											printf("\n\aError al mostrar la lista ordenada por titulo.\n");
										}
										break;

									case 3:
										printf("\nSaliendo del sub-menu de ordenamiento.\n");

									default:
										printf("\n\aError, ha ingresado un valor invalido.\n");
										break;
								}

							}while(optionSubMenu != 3);
						}

						break;

					case 6:
						// TODOS LOS ALBUMES ANTERIORES AL 2000
						if(!album_mostrarAlbumsAntes2000(list, artista, tipo, genero, tipoAlbum, len))
						{
							printf("\nLista de Albumes anteriores al 2000 mostrada con exito.\n");

							flag = TRUE;
						}
						else
						{
							printf("\n\aError al mostrar la lista de albumes anteriores al 2000.\n");
						}
						break;

					case 7:
						//TODOS LOS ALBUMES QUE SUPERAN EL PROMEDIO DE PRECIO
						if(!album_mostrarAlbumsExcedePromedio(list, artista, tipo, genero, tipoAlbum, len))
						{
							printf("\nLista de Albumes que exceden el promedio de precio mostrada con exito.\n");

							flag = TRUE;
						}
						else
						{
							printf("\n\aError al mostrar la lista de albumes que exceden el promedio de precio.\n");
						}
						break;

					case 8:
						// TODOS LOS ALBUMES DE CADA ARTISTA
						if(!album_mostrarTodosLosAlbumsPorArtista(list, artista, tipo, genero, tipoAlbum, len, lenArtista))
						{
							printf("\nLista de Albumes por Artista mostrada con exito.\n");

							flag = TRUE;
						}
						else
						{
							printf("\n\aError al mostrar la lista de Albumes por Artista.\n");
						}
						break;

					case 9:
						// TODOS LOS ALBUMES DE UN A�O EN ESPECIFICO
						if(!album_mostrarAlbumsPorAnio(list, artista, tipo, genero, tipoAlbum, len))
						{
							printf("\nLista de Albumes por anio mostrada con exito.\n");

							flag = TRUE;
						}
						else
						{
							printf("\n\aError al mostrar la lista de Albumes por anio.\n");
						}
						break;

					case 10:
						// EL ALBUM O LOS ALBUMES MAS CAROS
						if(!album_albumMasCaro(list, artista, tipo, genero, tipoAlbum, len))
						{
							printf("\nAlbumes mas caros mostrada con exito.\n");

							flag = TRUE;
						}
						else
						{
							printf("\n\aError al mostrar los albumes mas caros.\n");
						}
						break;

					case 11:
						if(!tipoAlbum_mostrarTipos(tipoAlbum, lenTipoAlbum))
						{
							printf("\nTipos de albumes mostrados con exito.\n");

							flag = TRUE;
						}
						else
						{
							printf("\n\aError, no se ha podido mostrar los tipos de albumes.\n");
						}
						break;

					case 12:
						if(!album_albumesNoVinilo(list, artista, tipo, genero, tipoAlbum, len))
						{
							printf("\nAlbumes que no son de vinilo mostrados con exito.\n");

							flag = TRUE;
						}
						else
						{
							printf("\n\aError, no se ha podido mostrar los albumes que no son de vinilo.\n");
						}
						break;

					case 13:
						if(!album_mostrarAlbumesDeViniloPorArtista(list, artista, tipo, genero, tipoAlbum, len, lenArtista, lenTipo, lenGenero, lenTipoAlbum))
						{
							printf("\nAlbumes de vinilo mostrado por artistas mostrado con exito.\n");

							flag = TRUE;
						}
						else
						{
							printf("\n\aError, no se ha podido mostrar los albumes de vinilo por artistas.\n");
						}
						break;

					case 14:
						printf("\nSaliendo del sub-menu de listas.\n\n");
						break;

					default:
						printf("\n\aError, ha ingresado un valor invalido.\n");
						break;
				}
			}

		}while(option != 11);

		if(flag)
		{
			toReturn = 0;
		}
	}


	return toReturn;
}

int album_mostrarUno(Album* unAlbum, Artista* unArtista, TipoArtista* tipo, Genero* genero, TipoAlbum* tipoAlbum)
{
	int toReturn = -1;

	if(unAlbum != NULL && unArtista != NULL && tipo != NULL && genero != NULL)
	{
		//ID TITULO FECHA DE PUBLICACION PRECIO ARTISTA TIPO DE ARTISTA GENERO
		printf("%d %20s %20d/%d/%d %20.2f %25s %15s %15s %15s\n", unAlbum->id, unAlbum->titulo, 	unAlbum->fechaPublicacion.dia, unAlbum->fechaPublicacion.mes,
														   unAlbum->fechaPublicacion.anio, 	unAlbum->precio, 				unArtista->nombre,
														   tipo->descripcion, 				genero->descripcion, tipoAlbum->descripcion);

		toReturn = 0;
	}

	return toReturn;
}

int album_mostrarAlbums(Album* list, int len, Artista* listArtista, int lenArtista, TipoArtista* listTipo, int lenTipo,
						Genero* listGenero, int lenGenero, TipoAlbum* listTipoAlbum, int lenTipoAlbum)
{
	int toReturn = -1;

	int i;
	int indexArtista;
	int indexTipo;
	int indexGenero;
	int indexTipoAlbum;

	if(list != NULL && len > 0 && listArtista != NULL && lenArtista > 0 && listTipo != NULL && lenTipo > 0 && listGenero != NULL && lenGenero > 0)
	{
		printf("\n\n");
		fflush(stdin);
		system("pause");

		printf("\t\tLISTA DE ALBUMES\n\n");
		printf("ID \t\t TITULO \t\t\t FECHA DE PUBLICACION \t PRECIO \t ARTISTA \t TIPO DE ARTISTA \t GENERO \t TIPO DE ALBUM\n\n");

		for(i = 0; i < len; i++)
		{
			indexArtista = artista_buscarPorId(listArtista, lenArtista, list[i].idArtista);
			indexTipo = tipoArtista_buscarPorId(listTipo, lenTipo, listArtista[i].idTipoArtista);
			indexGenero = genero_buscarPorId(listGenero, lenGenero, list[i].idGenero);
			indexTipoAlbum = tipoAlbum_buscarPorId(listTipoAlbum, lenTipoAlbum, list[i].idTipoAlbum);

			if(list[i].isEmpty == FALSE && album_mostrarUno(&list[i], &listArtista[indexArtista], &listTipo[indexTipo], &listGenero[indexGenero], &listTipoAlbum[indexTipoAlbum]))
			{
				break;
			}
		}

		if(i == len)
		{
			toReturn = 0;
		}
	}

	return toReturn;
}

// ============================ INFORMES ============================

int album_calcularInforme(Album* list, int len)
{
	int toReturn = -1;

	int contador;
	int contadorExcede;
	int contadorAntes2000;

	float acumulador;
	float promedio;

	if(list != NULL && len > 0)
	{
		if(!album_excedePromedio(list, len, &contador, &acumulador, &promedio, &contadorExcede) &&
		   !album_contarAlbumsAntes2000(list, len, &contadorAntes2000))
		{
			if(!album_mostrarResultados(acumulador, promedio, contadorExcede, contadorAntes2000))
			{
				toReturn = 0;
			}
		}
	}

	return toReturn;
}

int album_contador(Album* list, int len, int* contador)
{
	int toReturn = -1;

	int i;

	if(list != NULL && len > 0 && contador != NULL)
	{
		*contador = 0;

		for(i = 0; i < len; i++)
		{
			if(list[i].isEmpty == FALSE)
			{
				(*contador)++;
			}
		}

		toReturn = 0;
	}

	return toReturn;
}

int album_acumulador(Album* list, int len, float* acumulador)
{
	int toReturn = -1;

	int i;

	if(list != NULL && len > 0 && acumulador != NULL)
	{
		*acumulador = 0;

		for(i = 0; i < len; i++)
		{
			if(list[i].isEmpty == FALSE)
			{
				*acumulador =+ list[i].precio;
			}
		}

		toReturn = 0;
	}

	return toReturn;
}

int album_calcularPromedio(Album* list, int len, int* contador, float* promedio, float* acumulador)
{
	int toReturn = -1;

	if(list != NULL && len > 0 && promedio != NULL && acumulador != NULL)
	{
		*promedio = 0;

		if(!album_contador(list, len, contador) &&
		   !album_acumulador(list, len, acumulador))
		{
			if(contador > 0 && *acumulador > 0)
			{
				*promedio = *acumulador / *contador;

				toReturn = 0;
			}
		}

	}

	return toReturn;
}

int album_excedePromedio(Album* list, int len, int* contador, float* acumulador, float* promedio, int* contadorExcede)
{
	int toReturn = -1;

	int i;

	if(list != NULL && len > 0 && contador != NULL && acumulador != NULL && promedio != NULL && contadorExcede != NULL)
	{
		if(!album_calcularPromedio(list, len, contador, promedio, acumulador))
		{
			*contador = 0;

			for(i = 0; i < len; i++)
			{
				if(list[i].isEmpty == FALSE && list[i].precio > *promedio)
				{
					(*contador)++;
				}
			}

			toReturn = 0;
		}
	}

	return toReturn;
}

int album_mostrarResultados(float acumulador, float promedio, int contadorExcede, int contadorAntes2000)
{
	int toReturn = -1;

	if(acumulador > 0 && promedio > 0 && contadorExcede > 0 && contadorAntes2000 > 0)
	{
		printf("\tREPORTE DE PROMEDIO\n\n");

		printf("Suma total de precios: %.2f.\n", acumulador);
		printf("Promedio de precios: %.2f.\n", promedio);
		printf("Cantidad de albums que superar el promedio de precios: %d.\n", contadorExcede);
		printf("Cantidad de albums anteriores al 2000: %d.\n\n", contadorAntes2000);

		toReturn = 0;
	}

	return toReturn;
}

int album_contarAlbumsAntes2000(Album* list, int len, int* contador)
{
	int toReturn = -1;

	int i;

	if(list != NULL && len > 0 && contador != NULL)
	{
		*contador = 0;

		for(i = 0; i < len; i++)
		{
			if(list[i].fechaPublicacion.anio < 2000)
			{
				(*contador)++;
			}
		}

		toReturn = 0;
	}

	return toReturn;
}

// ============================ INFORMES 2 ============================

int album_mostrarAlbumsAntes2000(Album* list, Artista* artista, TipoArtista* tipo, Genero* genero, TipoAlbum* tipoAlbum, int len)
{
	int toReturn = -1;

	int i;
	int index;

	if(list != NULL && artista != NULL && tipo != NULL && genero != NULL && len > 0)
	{
		printf("\n\n");
		fflush(stdin);
		system("pause");

		printf("\t\tLISTA DE ALBUMS QUE SALIERON ANTES DEL 2000\n\n");
		printf("ID \tTITULO \t\tFECHA DE PUBLICACION \tPRECIO \t\tARTISTA \tTIPO DE ARTISTA \tGENERO\n\n");

		for(i = 0; i < len; i++)
		{
			if(list[i].isEmpty == FALSE && list[i].fechaPublicacion.anio < 2000)
			{
				index = album_buscarPorId(list, len, list[i].id);

				if(index > -1 && album_mostrarUno(&list[index], &artista[index], &tipo[index], &genero[index], &tipoAlbum[index]))
				{
					toReturn = 0;
				}
			}
		}
	}

	return toReturn;
}

int album_mostrarAlbumsExcedePromedio(Album* list, Artista* artista, TipoArtista* tipo, Genero* genero, TipoAlbum* tipoAlbum, int len)
{
	int toReturn = -1;

	int i;
	int index;

	int contador;
	float acumulador;
	float promedio;

	if(list != NULL && artista != NULL && tipo != NULL && genero != NULL && len > 0)
	{
		if(!album_calcularPromedio(list, len, &contador, &promedio, &acumulador))
		{
			printf("\n\n");
			fflush(stdin);
			system("pause");

			printf("\t\tLISTA DE ALBUMS QUE EXCEDEN EL PROMEDIO DE PRECIO\n\n");
			printf("ID \tTITULO \t\tFECHA DE PUBLICACION \tPRECIO \t\tARTISTA \tTIPO DE ARTISTA \tGENERO\n\n");

			for(i = 0; i < len; i++)
			{
				if(list[i].isEmpty == FALSE && list[i].precio > promedio)
				{
					index = album_buscarPorId(list, len, list[i].id);

					if(index > -1 && album_mostrarUno(&list[index], &artista[index], &tipo[index], &genero[index], &tipoAlbum[index]))
					{
						toReturn = 0;
					}
				}
			}
		}
	}

	return toReturn;
}

int album_mostrarTodosLosAlbumsPorArtista(Album* list, Artista* artista, TipoArtista* tipo, Genero* genero, TipoAlbum* tipoAlbum, int len, int lenArtista)
{
	int toReturn = -1;

	int i;
	int index;

	int flag;

	if(list != NULL && artista != NULL && tipo != NULL && genero != NULL && len > 0)
	{
		printf("\n\n");
		fflush(stdin);
		system("pause");

		printf("\t\tLISTA DE ALBUMES POR ARTISTAS\n\n");

		flag = FALSE;

		for(i = 0; i < len; i++)
		{
			if(list[i].isEmpty == FALSE)
			{
				index = artista_buscarPorId(artista, lenArtista, list[i].id);

				printf("Artista: %s.\n", artista[index].nombre);

				if(album_mostrarUno(&list[index], &artista[index], &tipo[index], &genero[index], &tipoAlbum[index]))
				{
					flag = TRUE;
				}
			}
		}

		if(flag)
		{
			toReturn = 0;
		}
	}

	return toReturn;
}

int album_mostrarAlbumsPorAnio(Album* list, Artista* artista, TipoArtista* tipo, Genero* genero, TipoAlbum* tipoAlbum, int len)
{
	int toReturn = -1;

	int i;
	int anio;
	int index;

	int flag = FALSE;

	if(list != NULL && artista != NULL && tipo != NULL && genero != NULL && len > 0)
	{
		for(i = 0; i < len; i++)
		{
			if(list[i].isEmpty == FALSE && !getInt(&anio, "\nIngrese el a�o el cual quiere mostrar los albums: ", "Error, solo numeros entre 1950 y 2021", 1950, 2021))
			{
				index = fecha_buscarFecha(list, len, anio);

				if(index > -1 && album_mostrarUno(&list[index], &artista[index], &tipo[index], &genero[index], &tipoAlbum[index]))
				{
					flag = TRUE;
				}
			}
		}

		if(flag)
		{
			toReturn = 0;
		}

	}

	return toReturn;
}

int album_albumMasCaro(Album* list, Artista* artista, TipoArtista* tipo, Genero* genero, TipoAlbum* tipoAlbum, int len)
{
	int toReturn = -1;

	int i;
	float max;

	int flag = FALSE;

	if(list != NULL && artista != NULL && tipo != NULL && genero != NULL && len > 0)
	{
		max = 0;

		for(i = 0; i < len; i++)
		{
			if(list[i].isEmpty != FALSE && list[i].precio > max)
			{
				if(album_mostrarUno(&list[i], &artista[i], &tipo[i], &genero[i], &tipoAlbum[i]))
				{
					flag = TRUE;
				}
			}
		}

		if(flag)
		{
			toReturn = 0;
		}
	}

	return toReturn;
}

int album_albumesNoVinilo(Album* list, Artista* artista, TipoArtista* tipo, Genero* genero, TipoAlbum* tipoAlbum1, int len)
{
	int toReturn = -1;

	int i;

	int flag = FALSE;

	if(list != NULL && artista != NULL && tipo && genero != NULL && tipoAlbum1 != NULL)
	{
		for(i = 0; i < len; i++)
		{
			if(list[i].idTipoAlbum != 1 && !album_mostrarUno(&list[i], &artista[i], &tipo[i], &genero[i], &tipoAlbum1[i]))
			{
				flag = TRUE;
			}
		}

		if(flag)
		{
			toReturn = 0;
		}
	}

	return toReturn;
}

int album_mostrarAlbumesDeViniloPorArtista(Album* list, Artista* artista, TipoArtista* tipo, Genero* genero, TipoAlbum* tipoAlbum1, int len, int lenArtista, int lenTipo, int lenGenero, int lenTipoAlbum)
{
	int toReturn = -1;

	int i;
	int input;

	int index;

	int flag = FALSE;

	if(list != NULL && artista != NULL && tipo != NULL && genero != NULL && tipoAlbum1 != NULL && len > 0)
	{
		if(!artista_mostrarArtistas(artista, tipo, lenArtista, lenTipo) && !getInt(&input, "Elija un artista: ", "Error, vuelva a intentarlo: ", 1, 6))
		{
			index = artista_buscarPorId(artista, lenArtista, input);

			for(i = 0; i < len; i++)
			{
				if(index > -1 && list[i].idTipoAlbum == 1)
				{
					if(!album_mostrarAlbums(list, len, artista, lenArtista, tipo, lenTipo, genero, lenGenero, tipoAlbum1, lenTipoAlbum))
					{
						flag = TRUE;
					}
				}

			}

			if(flag)
			{
				toReturn = 0;
			}
		}
	}

	return toReturn;
}
