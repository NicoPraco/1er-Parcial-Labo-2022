/*
 * tipoArtista.c
 *
 *  Created on: 1 may. 2022
 *      Author: Nicolas Praconovo
 */

#include "tipoArtista.h"

int tipoArtista_hardcodeo(TipoArtista* list, int len, int* id)
{
	int toReturn = -1;

	int i;
	int cant;

	TipoArtista auxTipo[] =
	{
		{0, "Solista", 	FALSE},
		{0, "Banda", 	FALSE},

	};

	if(list != NULL && len > 0)
	{
		cant = sizeof(auxTipo) / sizeof(TipoArtista);

		if(cant <= len)
		{
			for(i = 0; i < cant; i++)
			{
				list[i] = auxTipo[i];
				list[i].id = *id;

				(*id)++;
			}

			toReturn = 0;
		}
	}

	return toReturn;
}

int tipoArtista_buscarPorId(TipoArtista* list, int len, int id)
{
	int toReturn = -1;

	int i;

	if(list != NULL && len > 0)
	{
		for(i = 0; i < len; i++)
		{
			if(list[i].id == id)
			{
				toReturn = i;
				break;
			}
		}
	}

	return toReturn;
}

int tipoArtista_mostrarUno(TipoArtista* unTipo)
{
	int toReturn = -1;

	if(unTipo != NULL)
	{
		//ID	TIPO DE ARTISTA
		printf("%d %15s\n", unTipo->id, unTipo->descripcion);

		toReturn = 0;
	}

	return toReturn;
}


int tipoArtista_mostrarTipos(TipoArtista* list, int len)
{
	int toReturn = -1;

	int i;

	int flag = FALSE;

	if(list != NULL && len > 0)
	{
		printf("\n\n");
		fflush(stdin);
		system("pause");

		printf("\tLISTA DE TIPOS DE ARTISTAS\n\n");
		printf("ID \t TIPO DE ARTISTA\n\n");

		for(i = 0; i < len; i++)
		{
			if(list[i].isEmpty == FALSE && tipoArtista_mostrarUno(&list[i]))
			{
				flag = TRUE;
			}
		}

		if(flag)
		{
			toReturn = 0;
		}
	}
	return toReturn;
}
