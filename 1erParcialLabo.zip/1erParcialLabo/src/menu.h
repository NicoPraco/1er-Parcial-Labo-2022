/*
 * menu.h
 *
 *  Created on: 1 may. 2022
 *      Author: kualo
 */

#include <stdio.h>
#include <stdlib.h>

#include "input.h"

#ifndef MENU_H_
#define MENU_H_

int album_menuPrincipal(int* input);

int album_subMenuListar(int* input);

int album_subMenuOrdenamiento(int* input);

int album_menuOrdenamiento(int* input);

int album_ModificarMenu(int* input);

int album_menuArtistas(int* input);

int album_menuGenero(int* input);

int album_menuTipoAlbum(int* input);

#endif /* MENU_H_ */
