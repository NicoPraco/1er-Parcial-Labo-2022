/*
 * menu.c
 *
 *  Created on: 1 may. 2022
 *      Author: kualo
 */

#include "menu.h"

int album_menuPrincipal(int* input)
{
	int toReturn = -1;

	if(input != NULL)
	{
		printf("1. Alta Album.\n");
		printf("2. Baja Album.\n");
		printf("3. Modificar Album.\n");
		printf("4. Informes.\n");
		printf("5. Listar.\n");
		printf("6. Salir.\n\n");

		if(!getInt(input, "Elija una opcion: ", "Error, vuelva a intentarlo: ", 1, 6))
		{
			toReturn = 0;
		}
	}

	return toReturn;
}

int album_subMenuListar(int* input)
{
	int toReturn = -1;

	if(input != NULL)
	{
		printf("1. Todos los generos.\n");
		printf("2. Todos los tipos de artistas.\n");
		printf("3. Todos los artistas.\n");
		printf("4. Todos los albumes.\n");
		printf("5. Mostrar lista ordenada");
		printf("6. Todos los albumes cuya fecha de publicacion es anterior al 01/01/2001.\n");
		printf("7. Todos los albumes que superen el promedio de los importes.\n");
		printf("8. Todos los albumes de cada artista.\n");
		printf("9. Todos los albumes de un a�o determinado.\n");
		printf("10 El album o los albumes mas caros.\n");
		printf("11. Todos los tipos de albumes.\n");
		printf("12. Mostrar todos los albumes que no son de vinilo.\n");
		printf("13. Mostrar todos los albumes de vinilo de un artista determinado.\n");
		printf("14. Salir.\n\n");

		if(!getInt(input, "Elija una opcion: ", "Error, vuelva a intentarlo: ", 1, 14))
		{
			toReturn = 0;
		}
	}

	return toReturn;
}

int album_subMenuOrdenamiento(int* input)
{
	int toReturn = -1;

	if(input != NULL)
	{
		printf("1. Ordenamiento por Importe.\n");
		printf("2. Ordenamiento por Titulo.\n");
		printf("3. Salir.\n\n");

		if(!getInt(input, "Elija una opcion: ", "Error, vuelva a intentarlo: ", 1, 3))
		{
			toReturn = 0;
		}
	}

	return toReturn;
}

int album_menuOrdenamiento(int* input)
{
	int toReturn = -1;

	if(input != NULL)
	{
		printf("1. Orden Ascendente.\n");
		printf("2. Orden Descendente.\n");

		if(!getInt(input, "\nElija una opcion: ", "Error, vuelva a intentarlo: ", 1, 2))
		{
			toReturn = 0;
		}
	}

	return toReturn;
}

int album_ModificarMenu(int* input)
{
	int toReturn = -1;

	if(input != NULL)
	{
		printf("1. Modificar Titulo.\n");
		printf("2. Fecha de Publicacion.\n");
		printf("3. Importe.\n");
		printf("4. Salir.\n");

		if(!getInt(input, "\nElija una opcion: ", "Error, vuelva a intentarlo: ", 1, 3))
		{
			toReturn = 0;
		}
	}

	return toReturn;
}

int album_menuArtistas(int* input)
{
	int toReturn = -1;

	if(input != NULL)
	{

	 	printf("\nLos artistas disponibles son: \n\n");
		printf("1. The Beatles.\n");
		printf("2. Michael Jackson\n");
		printf("3. Ed Sheeran\n");
		printf("4. Hans Zimmer.\n");
		printf("5. Aimer.\n");
		printf("6. U2\n");

		if(!getInt(input, "\nElija una de las opciones disponibles: ", "Error, vuelva a intentarlo: ", 1, 6))
		{
			toReturn = 0;
		}
	}

	return toReturn;
}

int album_menuGenero(int* input)
{
	int toReturn = -1;

	if(input != NULL)
	{

	 	printf("\nLos generos disponibles son: \n\n");
		printf("1. Rock.\n");
		printf("2. Pop.\n");
		printf("3. Electronica.\n");
		printf("4. Jazz.\n");
		printf("5. Bandas Sonoras.\n");
		printf("6. K-Pop\n");
		printf("7. Country.\n");
		printf("8. Clasica.\n");
		printf("9. Reggaeton.\n");
		printf("10. J-Pop\n");

		if(!getInt(input, "\nElija una de las opciones disponibles: ", "Error, vuelva a intentarlo: ", 1, 10))
		{
			toReturn = 0;
		}
	}

	return toReturn;
}

int album_menuTipoAlbum(int* input)
{
	int toReturn = -1;

	if(input != NULL)
	{
		printf("1. Vinilo.\n");
		printf("2. Cinta.\n");
		printf("3. CD.\n\n");

		if(!getInt(input, "Elija una de las opciones disponibles:", "Error, vuelva a intentarlo: ", 1, 3))
		{
			toReturn = 0;
		}
	}

	return toReturn;
}
