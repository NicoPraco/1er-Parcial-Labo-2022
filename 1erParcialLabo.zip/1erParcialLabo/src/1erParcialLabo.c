/*
 ============================================================================
 Name        : 1erParcialLabo.c
 Author      : Praconovo, Nicolas Javier
 Version     : Windows
 Copyright   : -
 Description : 1er. Parcial Laboratorio.
 ============================================================================
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "input.h"
#include "menu.h"

#include "album.h"
#include "artista.h"
#include "tipoArtista.h"
#include "genero.h"

#define ALBUM_LEN 10
#define ARTISTA_LEN 6
#define TIPO_LEN 2
#define GENERO_LEN 10
#define TIPO_ALBUM_LEN 3

int main(void) {

	setbuf(stdout, NULL);

	Album arrayAlbum[ALBUM_LEN];
	Artista arrayArtista[ARTISTA_LEN];
	TipoArtista arrayTipo[TIPO_LEN];
	Genero arrayGenero[GENERO_LEN];
	TipoAlbum arrayTipoAlbum[TIPO_ALBUM_LEN];

	int idAlbum = 1;
	int idArtista = 1;
	int idTipo = 1;
	int idGenero = 1;
	int idTipoAlbum = 1;

	int option;
	int auxId;

	int valueReturnRemove;
	int valueReturnMod;

	if(!album_inicializar(arrayAlbum, ALBUM_LEN))
	{
		if(!album_hardcodeo(arrayAlbum, ALBUM_LEN, &idAlbum) 	&& !artista_hardcodeo(arrayArtista, ARTISTA_LEN, &idArtista) &&
		   !tipoArtista_hardcodeo(arrayTipo, TIPO_LEN, &idTipo) && !genero_hardcode(arrayGenero, GENERO_LEN, &idGenero) &&!tipoAlbum_hardcodeo(arrayTipoAlbum, TIPO_ALBUM_LEN, &idTipoAlbum))
		{
			do
			{
				if(!album_menuPrincipal(&option))
				{
					switch (option)
					{
						case 1:
							// CARGAR
							if(!album_cargarUno(arrayAlbum, ALBUM_LEN, &idAlbum))
							{
								printf("\nSe ha cargado un album con exito.\n");
							}
							else
							{
								printf("\n\aError al cargar un nuevo album.\n");
							}
							break;

						case 2:
							// MODIFICAR
							if(!arrayIsEmpty(arrayAlbum, ALBUM_LEN))
							{
								if(!album_mostrarAlbums(arrayAlbum, ALBUM_LEN, arrayArtista, ARTISTA_LEN, arrayTipo, TIPO_LEN, arrayGenero, GENERO_LEN, arrayTipoAlbum, TIPO_ALBUM_LEN)
										&&
								   !getInt(&auxId, "\nElija la id del album a modificar: ", "Error, vuelva a intentarlo: ", 1, 10))
								{
									valueReturnMod = album_modificar(arrayAlbum, arrayArtista, arrayTipo, arrayGenero, arrayTipoAlbum, ALBUM_LEN, auxId);

									switch (valueReturnMod)
									{
										case -1:
											printf("\n\aError al modificar el album.\n");
											break;

										case 0:
											printf("\nAlbum modificado con exito.\n");
											break;

										case 1:
											printf("\nEl usuario cancelo la modificacion.\n");
											break;

										default:
											printf("\n\aError, valor invalido.\n");
											break;
									}
								}
							}
							else
							{
								printf("\n\aError, no hay albumes que mostrar.\n");
							}
							break;

						case 3:
							// BAJA
							if(!arrayIsEmpty(arrayAlbum, ALBUM_LEN))
							{
								if(!album_mostrarAlbums(arrayAlbum, ALBUM_LEN, arrayArtista, ARTISTA_LEN, arrayTipo, TIPO_LEN, arrayGenero, GENERO_LEN, arrayTipoAlbum, TIPO_ALBUM_LEN)
										&&
								   !getInt(&auxId, "\nElija la id del album a modificar: ", "Error, vuelva a intentarlo: ", 1, 10))
								{
									valueReturnRemove = album_baja(arrayAlbum, arrayArtista, arrayTipo, arrayGenero, arrayTipoAlbum, ALBUM_LEN, auxId);

									switch (valueReturnRemove)
									{
										case -1:
											printf("\n\aError al eliminar el album.\n");
											break;

										case 0:
											printf("\nAlbum eliminado con exito.\n");
											break;

										case 1:
											printf("\nEl usuario cancelo la baja.\n");
											break;

										default:
											printf("\n\aError, valor invalido.\n");
											break;
									}
								}
							}
							else
							{
								printf("\n\aError, no hay albumes que mostrar.\n");
							}
							break;

						case 4:
							// INFORMAR
							if(!arrayIsEmpty(arrayAlbum, ALBUM_LEN))
							{
								if(!album_calcularInforme(arrayAlbum, ALBUM_LEN))
								{
									printf("\nInforme mostrado con exito.\n");
								}
								else
								{
									printf("\n\aError al realizar los informes.\n");
								}
							}
							else
							{
								printf("\n\aError, no hay albumes que mostrar.\n");
							}
							break;

						case 5:
							// LISTAR
							if(!arrayIsEmpty(arrayAlbum, ALBUM_LEN))
							{
								if(!album_menuMostrar(arrayAlbum, arrayArtista, arrayTipo, arrayGenero, arrayTipoAlbum, ALBUM_LEN, ARTISTA_LEN, TIPO_LEN, GENERO_LEN, TIPO_ALBUM_LEN))
								{
									printf("\nSub-menu de listas mostrado con exito.\n");
								}
								else
								{
									printf("\n\aError al mostrar el sub-menu de listas.\n");
								}
							}
							else
							{
								printf("\n\aError, no hay albumes que mostrar.\n");
							}
							break;

						case 6:
							printf("\nSaliendo del Menu Principal.\n");
							break;

						default:
							printf("\n\aError, ha ingresado un valor invalido.\n");
							break;
					}
				}
				else
				{
					printf("\n\aError, al mostrar el Menu Principal.\n");
				}

				printf("\n");
				fflush(stdin);
				system("pause");
				system("cls");

			}while(option != 6);

		}
		else
		{
			printf("\n\aError al hardcodeas datos.\n");
		}
	}
	else
	{
		printf("\n\aError al inicializar Albumes.\n");
	}


	return EXIT_SUCCESS;
}
