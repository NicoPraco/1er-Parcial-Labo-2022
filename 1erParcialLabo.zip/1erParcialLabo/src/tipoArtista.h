/*
 * tipoArtista.h
 *
 *  Created on: 1 may. 2022
 *      Author: Nicolas Praconovo
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "input.h"
#include "menu.h"

#define TIPO_ARTISTA_LENGHT 51

#define TRUE 1
#define FALSE 0

#ifndef TIPOARTISTA_H_
#define TIPOARTISTA_H_

typedef struct
{
	int id;
	char descripcion[TIPO_ARTISTA_LENGHT];

	int isEmpty;

} TipoArtista;

/**
 * \brief Hardcodea los datos de TipoArtista.
 *
 * \param list Lista de Tipo Artista.
 * \param len Cantidad de Elementos.
 * \param id ID el cual tendra los datos de la estructura.
 *
 * \return Retorna -1 si hubo un error, en caso contrario 0.
 */
int tipoArtista_hardcodeo(TipoArtista* list, int len, int* id);

/**
 * \brief Busca si el ID existe
 *
 * \param list Lista de Tipos de Artistas.
 * \param len Cantidad de Elementos
 * \param id ID a verificar.
 *
 * \return Retorna -1 si hubo un error, en caso contrario 0.
 */
int tipoArtista_buscarPorId(TipoArtista* list, int len, int id);

/**
 * \brief Muestra un solo tipo de artista.
 *
 * \param unTipo
 *
 * \return Retorna -1 si hubo un error, en caso contrario 0.
 */
int tipoArtista_mostrarUno(TipoArtista* unTipo);

/**
 * \brief Muestra la lista de Tipos de Artistas.
 *
 * \param list Lista de Genero.
 * \param len Cantidad de Elementos
 *
 * \return Retorna -1 si hubo un error, en caso contrario 0.
 */
int tipoArtista_mostrarTipos(TipoArtista* list, int len);


#endif /* TIPOARTISTA_H_ */
