/*
 * tipoAlbum.c
 *
 *  Created on: 3 may. 2022
 *      Author: kualo
 */

#include "tipoAlbum.h"

int tipoAlbum_hardcodeo(TipoAlbum* list, int len, int* id)
{
	int toReturn = -1;

	int i;
	int cant;

	TipoAlbum auxTipo[] =
	{
			{0, "Vinilo", 	FALSE},
			{0, "Cinta", 	FALSE},
			{0, "CD", 		FALSE},
	};

	if(list != NULL && len > 0 && id != NULL)
	{
		cant = sizeof(auxTipo) / sizeof(TipoAlbum);

		if(cant <= len)
		{
			for(i = 0; i < cant; i++)
			{
				list[i] = auxTipo[i];
				list[i].id = *id;

				(*id)++;
			}

			toReturn = 0;
		}
	}

	return toReturn;
}

int tipoAlbum_buscarPorId(TipoAlbum* list, int len, int id)
{
	int toReturn = -1;

	int i;

	if(list != NULL && len > 0)
	{
		for(i = 0; i < len; i++)
		{
			if(list[i].id == id)
			{
				toReturn = i;
				break;
			}
		}
	}

	return toReturn;
}

int tipoAlbum_mostrarUno(TipoAlbum* unTipo)
{
	int toReturn = -1;

	if(unTipo != NULL)
	{
		// ID	DESCRIPCION
		printf("%d %15s\n", unTipo->id, unTipo->descripcion);

		toReturn = 0;
	}

	return toReturn;
}

int tipoAlbum_mostrarTipos(TipoAlbum* list, int len)
{
	int toReturn = -1;

	int i;

	int flag = FALSE;

	if(list != NULL && len > 0)
	{
		printf("\n\n");
		fflush(stdin);
		system("pause");

		printf("\tLISTA DE GENEROS\n\n");
		printf("ID \t GENEROS\n\n");

		for(i = 0; i < len; i++)
		{
			if(list[i].isEmpty == FALSE && tipoAlbum_mostrarUno(&list[i]))
			{
				flag = TRUE;
			}
		}

		if(flag)
		{
			toReturn = 0;
		}
	}

	return toReturn;
}
