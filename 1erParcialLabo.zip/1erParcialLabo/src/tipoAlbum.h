/*
 * tipoAlbum.h
 *
 *  Created on: 3 may. 2022
 *      Author: kualo
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "input.h"
#include "menu.h"

#define TIPO_ALBUM_LENGHT 51

#define TRUE 1
#define FALSE 0

#ifndef TIPOALBUM_H_
#define TIPOALBUM_H_

typedef struct
{
	int id;
	char descripcion[TIPO_ALBUM_LENGHT];

	int isEmpty;

} TipoAlbum;

int tipoAlbum_hardcodeo(TipoAlbum* list, int len, int* id);

int tipoAlbum_buscarPorId(TipoAlbum* list, int len, int id);

int tipoAlbum_mostrarUno(TipoAlbum* unTipo);

int tipoAlbum_mostrarTipos(TipoAlbum* list, int len);

#endif /* TIPOALBUM_H_ */
