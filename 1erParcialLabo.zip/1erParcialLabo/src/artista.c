/*
 * artista.c
 *
 *  Created on: 1 may. 2022
 *      Author: Nicolas Praconovo
 */

#include "artista.h"

int artista_hardcodeo(Artista* list, int len, int* id)
{
	int toReturn = -1;

	int i;
	int cant;

	Artista auxArtista[] =
	{
			{0, "The Beatles", 		2, 		FALSE},
			{0, "Michael Jackson", 	1, 		FALSE},
			{0, "Ed Sheeran", 		1, 		FALSE},
			{0, "Hans Zimmer", 		2, 		FALSE},
			{0, "Aimer", 			1, 		FALSE},
			{0, "Keane", 			2, 		FALSE}
	};

	if(list != NULL && len > 0 && id != NULL)
	{
		cant = sizeof(auxArtista) / sizeof(Artista);

		if(cant <= len)
		{
			for(i = 0; i < cant; i++)
			{
				list[i] = auxArtista[i];
				list[i].id = *id;

				(*id)++;
			}

			toReturn = 0;
		}
	}

	return toReturn;
}

int artista_buscarPorId(Artista* list, int len, int id)
{
	int toReturn = -1;

	int i;

	if(list != NULL && len > 0)
	{
		for(i = 0; i < len; i++)
		{
			if(list[i].id == id)
			{
				toReturn = i;
				break;
			}
		}
	}

	return toReturn;
}

int artista_mostrarUno(Artista* unArtista, TipoArtista* tipo)
{
	int toReturn = -1;

	if(unArtista != NULL && tipo != NULL)
	{
		//ID 	NOMBRE 	ID TIPO DE ARTISTA
		printf("%d %15s %15s\n", unArtista->id, unArtista->nombre, tipo->descripcion);

		toReturn = 0;
	}

	return toReturn;
}

int artista_mostrarArtistas(Artista* list, TipoArtista* listTipo, int len, int lenTipo)
{
	int toReturn = -1;

	int i;
	int indexTipo;

	int flag = FALSE;

	if(list != NULL && len > 0 && listTipo != NULL && lenTipo > 0)
	{
		printf("\n\n");
		fflush(stdin);
		system("pause");

		printf("\tLISTA DE ARTISTAS\n\n");
		printf("ID \t NOMBRE \t TIPO DE ARTISTA\n");

		for(i = 0; i < len; i++)
		{
			indexTipo = tipoArtista_buscarPorId(listTipo, lenTipo, list[i].idTipoArtista);

			if(list[i].isEmpty == FALSE && artista_mostrarUno(&list[i], &listTipo[indexTipo]))
			{
				flag = TRUE;
			}
		}

		if(flag)
		{
			toReturn = 0;
		}
	}

	return toReturn;
}

